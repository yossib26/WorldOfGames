from Live import *

welcome("Yossi")
load_game()



