from Live import load_game, welcome

welcome("Yossi")
load_game()





